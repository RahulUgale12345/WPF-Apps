﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Wpf2waybind
{
    /// <summary>   
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //this.Loaded += new RoutedEventHandler(Page_Loaded);
            //this.button1.Click += new RoutedEventHandler(button1_Click);
        }

        private void InitializeComponent()
        {
            throw new NotImplementedException();
        }



        //void Page_Loaded(object sender, RoutedEventArgs e)
        //{
        //    Stu s = new Stu();

        //    {

        //        s.fname = "Shyam";

        //        s.lname = "Kumar";

        //    };

        //    this.StuInfo.DataContext = s;

        //}

        //void button1_Click(object sender, RoutedEventArgs e)

        //{

        //    Stu s = new Stu();

        //    {

        //        s.fname = "Rahul";

        //        s.lname = "Ugale";

        //    };

        //    this.StuInfo.DataContext = s;

        //}

        public class Person : INotifyPropertyChanged
        {
            private string _fisrtname;
            public string FirstName
            {
                get
                {
                              return _fisrtname;
                }
                set
                {
                    _fisrtname = value;
                    OnPropertyRaised("FirstName");
                    OnPropertyRaised("FullName");
                }
            }
            private string _lastname;
            public string LastName
            {
                get
                {
                               return _lastname;
                }
                set
                {
                    _lastname = value;
                    OnPropertyRaised("LastName");
                    OnPropertyRaised("FullName");
                }
            }
            private string _fullname;
            public string FullName
            {
                get
                {
                    return _fullname;
                }
                set
                {
                    _fullname = value;
                    OnPropertyRaised("FullName");
                }
            }
            public Person()
            {
                _fisrtname = "Nirav";
                _lastname = "Daraniya";
            }
            public event PropertyChangedEventHandler PropertyChanged;
            private void OnPropertyRaised(string propertyname)
            {
                if (PropertyChanged != null)
                {
                    PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
                }
            }
        }


    }
    //public class Stu
    //{
    //    public string fname { get; set; }
    //    public string lname { get; set; }
    //}

    public class Person
        {  
          private string _fisrtname;  
          public string FirstName
            {  
           get
                {
                      return _fisrtname;
                }  
            set
                {
                    _fisrtname = value;
                }  
       }  
          private string _lastname;  
          public string LastName
            {  
            get
                {
                                return _lastname;
                            }  
            set
                {
                    _lastname = value;
                }  
        }  
          private string _fullname;  
          public string FullName
            {  
            get
                {
                               return _fisrtname + " " + _lastname; ;
                }  
            set
                {
                    _fullname = value;
               }  
         }  
          public Person()
            {
                _fisrtname = "Nirav";
                _lastname = "Daraniya";
            }  
        }

}
